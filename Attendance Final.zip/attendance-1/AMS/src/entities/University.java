package entities;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class University {

    public static ArrayList<Course> courses;
    public static ArrayList<User> users;
    public static ArrayList<Enrollment> enrollments;
    public static ArrayList<Attendance> attendances;
    public static ArrayList<WorkLoad> workLoads;

    static {
        courses = new ArrayList();
        users = new ArrayList();
        enrollments = new ArrayList();
        attendances = new ArrayList();
        workLoads = new ArrayList();

    }

    public static void dummyUsers() {
        ArrayList<Section> sections1 = new ArrayList<>();
        sections1.add(new Section("W1", "Monday", "9-11 AM"));
        sections1.add(new Section("W2", "Wednesday", "2-4 PM"));
        ArrayList<Section> sections2 = new ArrayList<>();
        sections2.add(new Section("V1", "Tuesday", "10-12 AM"));
        sections2.add(new Section("V2", "Thursday", "1-3 PM"));
        ArrayList<Section> sections3 = new ArrayList<>();
        sections3.add(new Section("Y1", "Monday", "11-1 PM"));
        sections3.add(new Section("Y2", "Friday", "9-11 AM"));
        courses.add(new Course("Introduction to Programming", "CS101", sections1));
        courses.add(new Course("Data Structures", "CS102", sections2));
        courses.add(new Course("Database Systems", "CS103", sections3));
        users.add(new User("Asma Ismail", "asmaismail@gmail.com", "asma123", "What is your favorite color?", "red", "no role", "03274931715"));
        users.add(new Student("Ali", "ali@gmail.com", "ali123", "What is your favorite color?", "Blue", "Student", "03123456789"));
        users.add(new Student("Ayesha", "ayesha@gmail.com", "ayesha123", "What is your pet's name?", "Fluffy", "Student", "03098765432"));
        users.add(new Student("Amna", "amna@gmail.com", "amna123", "What was your first car?", "Toyota", "Student", "03012349876"));
        users.add(new Teacher("Bilal Arif", "bilal@gmail.com", "teachPass123", "What was your high school name?", "Lincoln High", "Teacher", "03111222333"));
        users.add(new Teacher("Abdullah Yousaf", "abdullah@gmail.com", "teachsecure123", "Your First Teacher Name?", "Mrs. Johnson", "Teacher", "03099887766"));
        users.add(new Teacher("Emily Davis", "emily.davis@gmail.com", "teachSafe123", "What is your hobby?", "Reading", "Teacher", "03123456780"));
    }

    public static void dialogeMsg(String msg) {
        JOptionPane.showMessageDialog(null, msg);
    }

    public static ArrayList<User> getUser(String role) {
        ArrayList<User> u = new ArrayList();
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getRole().equals(role)) {
                u.add(users.get(i));
            }
        }
        return u;
    }

    public static String[] specifcEnrolledStudent(String teacherName, String courseName, String sectionName) {
        ArrayList<String> students = new ArrayList<>();

        for (Enrollment e : enrollments) {
            ArrayList<Section> sections = e.getCourse().getSections();
            for (Section s : sections) {
                if (e.getTea().getName().equalsIgnoreCase(teacherName) && e.getCourse().getName().equalsIgnoreCase(courseName) && s.getName().equalsIgnoreCase(sectionName) && e.getStatus().equalsIgnoreCase("approved")) {
                    students.add(e.getStd().getName());
                }
            }
        }
        String[] studentArray = new String[students.size()];
        studentArray = students.toArray(studentArray);
        return studentArray;
    }

    public static String[] teacherAssignedCourse(String teacherName) {
        ArrayList<String> uniqueCourses = new ArrayList<>();
        for (WorkLoad c : workLoads) {
            if (c.getTeacher().getName().equalsIgnoreCase(teacherName)) {
                String courseName = c.getCourse().getName();
                if (!uniqueCourses.contains(courseName)) {
                    uniqueCourses.add(courseName);
                }
            }
        }
        String[] courseNameArray = new String[uniqueCourses.size()];
        courseNameArray = uniqueCourses.toArray(courseNameArray);
        return courseNameArray;
    }

    public static boolean createCourse(Course c) {
        if (c != null) {
            courses.add(c);
            return true;
        } else {
            return false;
        }
    }

    public static ArrayList<Enrollment> searchEnrolledStudent(String name) {
        ArrayList<Enrollment> matchingEnrollments = new ArrayList<>();
        for (Enrollment e : enrollments) {
            if (e.getStd().getName().toLowerCase().contains(name.toLowerCase())) {
                matchingEnrollments.add(e);
            }
        }
        return matchingEnrollments;
    }

    public static ArrayList<WorkLoad> allAssignedCourses(String name) {
        ArrayList<WorkLoad> enrolledStudents = new ArrayList<>();
        for (WorkLoad work : workLoads) {
            if (work.getTeacher().getName().equalsIgnoreCase(name)) {
                enrolledStudents.add(work);
            }
        }
        return enrolledStudents;
    }

    public static Course getCourseWithSections(String courseName, String sectionName) {
        for (Course c : courses) {
            if (c.getName().equalsIgnoreCase(courseName.trim())) {
                ArrayList<Section> matchedSections = new ArrayList<>();
                for (Section s : c.getSections()) {
                    if (s.getName().equalsIgnoreCase(sectionName.trim())) {
                        matchedSections.add(s);
                        return new Course(c.getName(), c.getC_code(), matchedSections);
                    }
                }
            }
        }
        return null;
    }

    public static User loginUser(String u_name, String pass) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getEmail().equals(u_name)
                    && pass.equals(users.get(i).getPassword())) {
                return users.get(i);
            }
        }
        return null;
    }

    public static String specificStudentAttendance(String name) {
        for (Attendance a : attendances) {
            if (a.getName().equalsIgnoreCase(name)) {
                if (a.getAttendance().equalsIgnoreCase("false")) {
                    return "A";
                } else if (a.getAttendance().equalsIgnoreCase("true")) {
                    return "P";
                }
            }
        }
        return null;
    }

    public static String[] specifcEnrolledStudent(String courseName, String sectionName) {
        ArrayList<String> students = new ArrayList<>();

        for (Enrollment e : enrollments) {
            ArrayList<Section> sections = e.getCourse().getSections();
            for (Section s : sections) {
                if (e.getCourse().getName().equalsIgnoreCase(courseName) && s.getName().equalsIgnoreCase(sectionName) && e.getStatus().equalsIgnoreCase("approved")) {
                    students.add(e.getStd().getName());
                }
            }
        }
        String[] studentArray = new String[students.size()];
        studentArray = students.toArray(studentArray);
        return studentArray;
    }

    public static boolean markAttendance(Attendance a) {
        if (a != null) {
            for (Attendance attendance : attendances) {
                if (a.getName().equalsIgnoreCase(attendance.getName())) {
                    attendance.setAttendance(a.getAttendance());
                    return true;
                }
            }
            attendances.add(a);
            return true;
        }
        return false;
    }

    public static ArrayList<Enrollment> getEnrollment() {
        return enrollments;
    }

    public static boolean WorkLoad(WorkLoad work) {
        if (work != null) {
            workLoads.add(work);
            return true;
        } else {
            return false;
        }
    }

    public static ArrayList<Enrollment> advisorValues(String name) {
        ArrayList<Enrollment> enrolledStudents = new ArrayList<>();
        for (Enrollment enroll : enrollments) {
            if (enroll.getTea().getName().equalsIgnoreCase(name) && !(enroll.getStatus().equalsIgnoreCase("approved"))) {
                enrolledStudents.add(enroll);
            }
        }
        return enrolledStudents;
    }

    public static String[] teacherAssignedSections(String courseName) {
        ArrayList<String> matchingSections = new ArrayList<>();

        for (WorkLoad c : workLoads) {
            if (c.getCourse().getName().equalsIgnoreCase(courseName)) {
                ArrayList<Section> sections = c.getCourse().getSections();
                for (Section s : sections) {
                    matchingSections.add(s.getName());
                }
            }
        }
        String[] sectionNameArray = new String[matchingSections.size()];
        sectionNameArray = matchingSections.toArray(sectionNameArray);
        return sectionNameArray;
    }

    public static String[] getAllCoursesFromWorkload() {
        ArrayList<String> courseList = new ArrayList<>();

        for (WorkLoad c : workLoads) {
            String courseName = c.getCourse().getName();
            if (!courseList.contains(courseName)) {
                courseList.add(courseName);
            }
        }
        return courseList.toArray(new String[0]);
    }

    public static ArrayList<WorkLoad> getWorkloadList() {
        return workLoads;
    }

    public static String verifyUser(String u_name, String pass) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getEmail().equals(u_name)
                    && pass.equals(users.get(i).getPassword())) {
                return users.get(i).getRole();

            }
        }
        return null;
    }

    public static boolean registerUser(User u) {
        if (u != null && u.getRole().equalsIgnoreCase("Teacher")) {
            users.add(new Teacher(u.getName(), u.getEmail(), u.getPassword(), u.getSecurity_q(), u.getSecurity_a(), u.getRole(), u.getPh_no()));
            return true;
        } else if (u != null && u.getRole().equalsIgnoreCase("Student")) {
            users.add(new Student(u.getName(), u.getEmail(), u.getPassword(), u.getSecurity_q(), u.getSecurity_a(), u.getRole(), u.getPh_no()));
            return true;
        }
        return false;

    }

    public static void UpdateUser(User obj, String email) {
        for (User u : users) {
            if (email.trim().equals(u.getEmail())) {
                u.setName(obj.getName());
                u.setEmail(email);
                u.setRole(obj.getRole());
                u.setPh_no(obj.getPh_no());
                u.setSecurity_a(obj.getSecurity_a());
                u.setSecurity_q(obj.getSecurity_q());
                u.setPassword(obj.getPassword());
            }
        }
    }

    public static boolean Enrollment(Enrollment enroll) {
        if (enroll != null) {
            enrollments.add(enroll);
            return true;
        } else {
            return false;
        }
    }

    public static String[] UserNameList(String role) {
        String[] studenrNames = new String[users.size()];
        int index = 0;
        for (User u : users) {
            if (u.getRole().trim().equals(role)) {
                studenrNames[index] = u.getName();
                index++;
            }
        }
        return studenrNames;
    }

    public static User UserSearchByName(String name, String role) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getName().equals(name)
                    && role.equals(users.get(i).getRole())) {
                return users.get(i);
            }
        }
        return null;
    }

    public static String[] CourseNameList() {
        String[] courseNames = new String[courses.size()];
        int index = 0;
        for (Course c : courses) {
            courseNames[index] = c.getName();
            index++;
        }
        return courseNames;
    }

    public static String[] SectionName(String courseName) {
        ArrayList<String> matchingSections = new ArrayList<>();

        for (Course c : courses) {
            if (c.getName().equalsIgnoreCase(courseName.trim())) {
                ArrayList<Section> sections = c.getSections();
                for (Section s : sections) {
                    matchingSections.add(s.getName());
                }
            }
        }
        String[] sectionNamesArray = new String[matchingSections.size()];
        sectionNamesArray = matchingSections.toArray(sectionNamesArray);

        return sectionNamesArray;

    }

    public static String TeacherWorkLoad(String course, String section) {
        for (WorkLoad work : workLoads) {
            for (Section s : work.getCourse().getSections()) {
                if (work.getCourse().getName().trim().equalsIgnoreCase(course.trim()) && s.getName().trim().equalsIgnoreCase(section.trim())) {
                    return work.getTeacher().getName();
                }
            }
        }
        return null;
    }

    public static ArrayList<User> search(String name, String role) {
        ArrayList<User> matchingUsers = new ArrayList<>();
        for (User u : users) {
            if (u.getName().toLowerCase().contains(name.toLowerCase()) && u.getRole().trim().equals(role)) {
                matchingUsers.add(u);
            }
        }
        return matchingUsers;
    }

    public static String recoverPassword(String email, String securityQuestion, String securityAnswer) {
        for (User user : users) {
            if (user.getEmail().equals(email)) {
                if (user.getSecurity_q().equals(securityQuestion) && user.getSecurity_a().equals(securityAnswer)) {
                    return user.getPassword();
                } else {
                    return "Security question or answer is incorrect.";
                }
            }
        }
        return "User not found.";
    }

}
