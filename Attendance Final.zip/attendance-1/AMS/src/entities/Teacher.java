package entities;

public class Teacher extends User {

    public Teacher() {
    }

    public Teacher(String name, String email, String password, String security_q, String security_a, String role, String ph_no) {
        super(name, email, password, security_q, security_a, role, ph_no);

    }

}
