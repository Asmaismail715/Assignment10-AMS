
package driver;
public class AMS {
       public static void main(String[] args) {
       
    }
    
}
