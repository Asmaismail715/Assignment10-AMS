package frames;

import entities.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;

public class Admin_portal extends javax.swing.JFrame {

    private DefaultTableModel model;
    private Timer t;
    private SimpleDateFormat sdf;

    /**
     * Creates new form Admin_portal
     */
    public Admin_portal() {
        initComponents();
        this.setLocationRelativeTo(null);
        date();
        time();
        University.dummyUsers();
        defaultTextSetter();
        showStudentList("Student", studentTable);
        showStudentList("Teacher", teacherTable);
        for (String s : University.UserNameList("Student")) {
            if (s != null) {
                studentName.addItem(s.trim());
            }
        }
        addCourse();
        if (University.getEnrollment() != null) {
            showEnrolledList();
        }
        for (String s : University.UserNameList("Teacher")) {
            if (s != null) {
                teacherName.addItem(s.trim());
                advisorPortalSearch.addItem(s.trim());
            }
        }
        if (University.getWorkloadList() != null) {
            showWorkloadList();
        }
        if (Login.obj != null) {
            profileSetting(Login.obj);
        }
    }

    private void showStudentList(String role, JTable table) {
        model = (DefaultTableModel) table.getModel();
        ArrayList<User> list = University.getUser(role);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                Object[] col = new Object[6];
                col[0] = list.get(i).getName();
                col[1] = list.get(i).getEmail();
                col[2] = list.get(i).getPh_no();
                col[3] = list.get(i).getPassword();
                col[4] = list.get(i).getSecurity_q();
                col[5] = list.get(i).getSecurity_a();
                model.addRow(col);
            }
        }
    }

    void searchedStudents(ArrayList<User> list, JTable table) {
        model = (DefaultTableModel) table.getModel();
        if (list != null) {
            model.setRowCount(0);
            for (int i = 0; i < list.size(); i++) {
                Object[] col = new Object[6];
                col[0] = list.get(i).getName();
                col[1] = list.get(i).getEmail();
                col[2] = list.get(i).getPh_no();
                col[3] = list.get(i).getPassword();
                col[4] = list.get(i).getSecurity_q();
                col[5] = list.get(i).getSecurity_a();
                model.addRow(col);
            }
        }
    }

    private void showEnrolledList() {
        model = (DefaultTableModel) studentEnrollmentTable.getModel();
        model.setRowCount(0);
        ArrayList<Enrollment> list = University.getEnrollment();
        if (list != null) {
            for (Enrollment enroll : list) {
                ArrayList<Section> sections = enroll.getCourse().getSections();
                for (Section section : sections) {
                    Object[] col = new Object[6];
                    col[0] = enroll.getStd().getName();
                    col[1] = enroll.getCourse().getName();
                    col[2] = enroll.getTea().getName();
                    col[3] = section.getName();
                    col[4] = section.getClass_days();
                    col[5] = section.getClass_time_slot();
                    model.addRow(col);
                }
            }
        }
    }

    private void showWorkloadList() {
        model = (DefaultTableModel) workloadtable.getModel();
        model.setRowCount(0);
        ArrayList<WorkLoad> list = University.getWorkloadList();
        if (list != null) {
            for (WorkLoad work : list) {
                ArrayList<Section> sections = work.getCourse().getSections();
                for (Section section : sections) {
                    Object[] col = new Object[5];
                    col[0] = work.getTeacher().getName();
                    col[1] = work.getCourse().getName();
                    col[2] = section.getName();
                    col[3] = section.getClass_days();
                    col[4] = section.getClass_time_slot();
                    model.addRow(col);
                }
            }
        }
    }

    void defaultTextSetter() {
        adminName.setEditable(false);
        adminPass.setEditable(false);
        adminEmail.setEditable(false);
        adminAns.setEditable(false);
        adminPh.setEditable(false);
        A_portalCourse.setEnabled(false);
        A_PortalSection.setEnabled(false);
    }

    void profileSetting(User obj) {
        adminName.setText(obj.getName());
        adminPass.setText(obj.getPassword());
        adminEmail.setText(obj.getEmail());
        adminQue.setSelectedItem(obj.getSecurity_q());
        adminAns.setText(obj.getSecurity_a());
        adminPh.setText(obj.getPh_no());
    }
    String dd;

    public void date() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyy-MM-dd");
        dd = sdf.format(d);
        date.setText(dd);

    }

    public void time() {

        t = new Timer(0, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date dt = new Date();
                sdf = new SimpleDateFormat("hh:mm:ss a");
                String s = sdf.format(dt);
                time.setText(s);
            }
        });
        t.start();
    }

    private void addCourse() {
        course.removeAllItems();
        teacherCourse.removeAllItems();
        A_portalCourse.removeAllItems();
        A_report_course.removeAllItems();
        for (String s : University.CourseNameList()) {
            if (s != null) {
                course.addItem(s.trim());
                teacherCourse.addItem(s);
                A_portalCourse.addItem(s);
                A_report_course.addItem(s);
            }
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        status_combo1 = new javax.swing.JComboBox<>();
        dashboard2 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        Welcome = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        pic_label = new javax.swing.JLabel();
        Course = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        courseName = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        courseCode = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        courseTable = new javax.swing.JTable();
        AddSection = new javax.swing.JLabel();
        deletesection = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel66 = new javax.swing.JLabel();
        Attendance = new javax.swing.JPanel();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jPanel16 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        A_portalCourse = new javax.swing.JComboBox<>();
        A_PortalSection = new javax.swing.JComboBox<>();
        create = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        date = new javax.swing.JLabel();
        time = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        attendanceTable = new javax.swing.JTable();
        jPanel17 = new javax.swing.JPanel();
        A_report_course = new javax.swing.JComboBox<>();
        A_report_section = new javax.swing.JComboBox<>();
        jScrollPane9 = new javax.swing.JScrollPane();
        allAttendanceTable = new javax.swing.JTable();
        jPanel25 = new javax.swing.JPanel();
        jLabel76 = new javax.swing.JLabel();
        Student = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        studentSearch = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        teacher = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        course = new javax.swing.JComboBox<>();
        studentName = new javax.swing.JComboBox<>();
        studentSection = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        studentEnrollmentTable = new javax.swing.JTable();
        Setting = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        adminName = new javax.swing.JTextField();
        jPanel14 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        adminEmail = new javax.swing.JTextField();
        adminPh = new javax.swing.JTextField();
        adminPass = new javax.swing.JTextField();
        adminAns = new javax.swing.JTextField();
        adminQue = new javax.swing.JComboBox<>();
        jLabel65 = new javax.swing.JLabel();
        Teacher = new javax.swing.JPanel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel10 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        searchTeacher = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        teacherTable = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        teacherCourse = new javax.swing.JComboBox<>();
        teacherSection = new javax.swing.JComboBox<>();
        teacherName = new javax.swing.JComboBox<>();
        jPanel11 = new javax.swing.JPanel();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        workloadtable = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jLabel55 = new javax.swing.JLabel();
        status_combo = new javax.swing.JComboBox<>();
        jLabel67 = new javax.swing.JLabel();
        advisorPortalSearch = new javax.swing.JComboBox<>();
        jScrollPane7 = new javax.swing.JScrollPane();
        studentStatusTable = new javax.swing.JTable();
        jPanel19 = new javax.swing.JPanel();
        jLabel68 = new javax.swing.JLabel();
        Userportal = new javax.swing.JPanel();
        jLabel56 = new javax.swing.JLabel();
        UserName = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        userNum = new javax.swing.JTextField();
        userPass = new javax.swing.JTextField();
        userEmail = new javax.swing.JTextField();
        jLabel61 = new javax.swing.JLabel();
        userAns = new javax.swing.JTextField();
        jLabel62 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        userRole = new javax.swing.JComboBox<>();
        userQue = new javax.swing.JComboBox<>();
        jPanel12 = new javax.swing.JPanel();
        jLabel64 = new javax.swing.JLabel();

        status_combo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "Approved", "Cancelled" }));
        status_combo1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        status_combo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                status_combo1ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1000, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dashboard2.setBackground(new java.awt.Color(255, 102, 102));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/home.png"))); // NOI18N
        jLabel19.setText(" Home");
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/course_icon.png"))); // NOI18N
        jLabel20.setText(" Course Panel");
        jLabel20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel20MouseClicked(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/attendance.png"))); // NOI18N
        jLabel21.setText(" A Portal");
        jLabel21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel21MouseClicked(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/graduating-student.png"))); // NOI18N
        jLabel22.setText("Student Portal");
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/setting.png"))); // NOI18N
        jLabel23.setText("Setting");
        jLabel23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel23MouseClicked(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/teacher.png"))); // NOI18N
        jLabel24.setText("Teacher Portal");
        jLabel24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel24MouseClicked(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/user.png"))); // NOI18N
        jLabel25.setText("User Portal");
        jLabel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel25MouseClicked(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/logout.png"))); // NOI18N
        jLabel26.setText("Log out");
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel26MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout dashboard2Layout = new javax.swing.GroupLayout(dashboard2);
        dashboard2.setLayout(dashboard2Layout);
        dashboard2Layout.setHorizontalGroup(
            dashboard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboard2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(dashboard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(42, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, dashboard2Layout.createSequentialGroup()
                .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        dashboard2Layout.setVerticalGroup(
            dashboard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dashboard2Layout.createSequentialGroup()
                .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel19)
                .addGap(27, 27, 27)
                .addComponent(jLabel20)
                .addGap(26, 26, 26)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(75, Short.MAX_VALUE))
        );

        getContentPane().add(dashboard2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 610));

        jTabbedPane1.setBackground(new java.awt.Color(0, 153, 153));
        jTabbedPane1.setForeground(new java.awt.Color(255, 255, 255));

        Welcome.setBackground(new java.awt.Color(255, 255, 255));
        Welcome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                WelcomeMouseClicked(evt);
            }
        });
        Welcome.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 102, 102));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("Students");

        jLabel29.setBackground(new java.awt.Color(255, 102, 102));
        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("500+");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        Welcome.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 270, -1));

        jPanel4.setBackground(new java.awt.Color(255, 102, 102));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText("Courses");

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setText("100+");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jLabel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel31)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Welcome.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 160, 270, 90));

        jPanel5.setBackground(new java.awt.Color(255, 102, 102));

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("Teachers");

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setText("200+");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel32, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                        .addGap(53, 53, 53))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel32, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel33, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        Welcome.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 290, 340, 100));

        pic_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/Download final.jpg"))); // NOI18N
        Welcome.add(pic_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 700, 540));

        jTabbedPane1.addTab("Welcome", Welcome);

        Course.setBackground(new java.awt.Color(255, 255, 255));
        Course.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setBackground(new java.awt.Color(255, 102, 102));
        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(51, 0, 0));
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("Course Name");
        Course.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 159, -1));
        Course.add(courseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 244, -1));

        jLabel35.setBackground(new java.awt.Color(255, 102, 102));
        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(51, 0, 0));
        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText("Course Code");
        Course.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, 159, -1));
        Course.add(courseCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 50, 243, -1));

        courseTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Days", "Timing"
            }
        ));
        courseTable.setShowGrid(true);
        jScrollPane1.setViewportView(courseTable);

        Course.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, 493, 326));

        AddSection.setBackground(new java.awt.Color(255, 102, 102));
        AddSection.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        AddSection.setForeground(new java.awt.Color(51, 0, 0));
        AddSection.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        AddSection.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/add.png"))); // NOI18N
        AddSection.setText("Section");
        AddSection.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddSectionMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                AddSectionMouseEntered(evt);
            }
        });
        Course.add(AddSection, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 159, -1));

        deletesection.setBackground(new java.awt.Color(255, 102, 102));
        deletesection.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        deletesection.setForeground(new java.awt.Color(51, 0, 0));
        deletesection.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        deletesection.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/delete.png"))); // NOI18N
        deletesection.setText("Section");
        deletesection.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deletesectionMouseClicked(evt);
            }
        });
        Course.add(deletesection, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, 119, -1));

        jPanel7.setBackground(new java.awt.Color(0, 153, 153));
        jPanel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel7MouseClicked(evt);
            }
        });

        jLabel66.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 255, 255));
        jLabel66.setText("Create Course");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(182, 182, 182)
                .addComponent(jLabel66)
                .addContainerGap(190, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel66)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        Course.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 460, 490, 40));

        jTabbedPane1.addTab("Course Portal", Course);

        jLabel47.setBackground(new java.awt.Color(255, 153, 102));
        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/editing.png"))); // NOI18N
        jLabel47.setText("Active");
        jLabel47.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel47MouseClicked(evt);
            }
        });

        A_portalCourse.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { ".....Select Course....." }));
        A_portalCourse.setEnabled(false);
        A_portalCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_portalCourseActionPerformed(evt);
            }
        });

        A_PortalSection.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...Select Section..." }));
        A_PortalSection.setEnabled(false);
        A_PortalSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_PortalSectionActionPerformed(evt);
            }
        });

        create.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        create.setForeground(new java.awt.Color(255, 102, 102));
        create.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/attendance.png"))); // NOI18N
        create.setText("Create Attendance");
        create.setEnabled(false);
        create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(0, 153, 153));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Save");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        date.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        date.setText("Date");

        time.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        time.setText("Time");

        attendanceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        attendanceTable.setShowGrid(true);
        attendanceTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane11.setViewportView(attendanceTable);

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(A_portalCourse, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(58, 58, 58)
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addComponent(A_PortalSection, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(create, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel16Layout.createSequentialGroup()
                                .addGap(130, 130, 130)
                                .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(time, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 715, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(72, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(date)
                        .addComponent(time))
                    .addComponent(jLabel47))
                .addGap(23, 23, 23)
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(A_portalCourse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(A_PortalSection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(create))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(jButton4)
                .addContainerGap(114, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("A Portal", jPanel16);

        A_report_course.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...Select Course..." }));
        A_report_course.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_report_courseActionPerformed(evt);
            }
        });

        A_report_section.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...Select Section..." }));
        A_report_section.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                A_report_sectionActionPerformed(evt);
            }
        });

        allAttendanceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Name", "Status"
            }
        ));
        allAttendanceTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        allAttendanceTable.setEnabled(false);
        allAttendanceTable.setShowHorizontalLines(true);
        allAttendanceTable.setShowVerticalLines(true);
        jScrollPane9.setViewportView(allAttendanceTable);

        jPanel25.setBackground(new java.awt.Color(0, 153, 153));
        jPanel25.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel25MouseClicked(evt);
            }
        });

        jLabel76.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(255, 255, 255));
        jLabel76.setText("Show");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel76)
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel76, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(132, Short.MAX_VALUE))
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(A_report_course, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(88, 88, 88)
                .addComponent(A_report_section, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(A_report_course, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(A_report_section, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(97, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("Attendance Report", jPanel17);

        javax.swing.GroupLayout AttendanceLayout = new javax.swing.GroupLayout(Attendance);
        Attendance.setLayout(AttendanceLayout);
        AttendanceLayout.setHorizontalGroup(
            AttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AttendanceLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTabbedPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 793, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        AttendanceLayout.setVerticalGroup(
            AttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane4)
        );

        jTabbedPane1.addTab("A Portal", Attendance);

        Student.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel36.setText("Search Student");

        studentSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                studentSearchKeyReleased(evt);
            }
        });

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Email", "ph#", "Password"
            }
        ));
        jScrollPane3.setViewportView(studentTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(studentSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 676, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 440, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 632, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(studentSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(90, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("List of Students", jPanel1);

        teacher.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        teacher.setText("Bilal Arif");

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel38.setText("Section");

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel39.setText("Student");

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/teacher.png"))); // NOI18N
        jLabel40.setText("Teacher Name:");

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel41.setText("Course");

        course.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                courseActionPerformed(evt);
            }
        });

        studentSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentSectionActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(0, 204, 204));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 102, 102)));
        jPanel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel6MouseClicked(evt);
            }
        });

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/course_icon.png"))); // NOI18N
        jLabel42.setText("Enroll");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel42)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel42, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        studentEnrollmentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Name", "Course", "Teacher Name", "Section", "Days", "Time"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(studentEnrollmentTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(studentName, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(17, 17, 17)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(101, 101, 101)
                                .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(teacher))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(56, 56, 56)
                                        .addComponent(course, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(48, 48, 48)
                                        .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(69, 69, 69)
                                        .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(57, 57, 57)
                                        .addComponent(studentSection, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 752, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 390, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel39)
                    .addComponent(jLabel41)
                    .addComponent(jLabel38))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(studentName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(course, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(studentSection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel40)
                        .addComponent(teacher))
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(81, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Student Enrollment", jPanel2);

        Student.add(jTabbedPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        jTabbedPane1.addTab("Student Portal", Student);

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel43.setText("Profile");

        adminName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminName.setText("Name");
        adminName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));

        jPanel14.setBackground(new java.awt.Color(0, 153, 153));
        jPanel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel14MouseClicked(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel46.setText("Update");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap(82, Short.MAX_VALUE)
                .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jLabel46)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        adminEmail.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminEmail.setText("Email");
        adminEmail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));

        adminPh.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminPh.setText("Ph#");
        adminPh.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));

        adminPass.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminPass.setText("Password");
        adminPass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));

        adminAns.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminAns.setText("Answer");
        adminAns.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));

        adminQue.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminQue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "What is your pet name?", "What is your School name?", "What is your favourite teacher name?" }));
        adminQue.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153)));

        jLabel65.setBackground(new java.awt.Color(255, 153, 102));
        jLabel65.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel65.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/editing.png"))); // NOI18N
        jLabel65.setText("Active");
        jLabel65.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel65MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout SettingLayout = new javax.swing.GroupLayout(Setting);
        Setting.setLayout(SettingLayout);
        SettingLayout.setHorizontalGroup(
            SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SettingLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SettingLayout.createSequentialGroup()
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(SettingLayout.createSequentialGroup()
                        .addGroup(SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(adminName, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminPh, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(adminQue, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 156, Short.MAX_VALUE)
                        .addGroup(SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SettingLayout.createSequentialGroup()
                                .addGroup(SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(adminAns, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(adminEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(adminPass, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(128, 128, 128))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SettingLayout.createSequentialGroup()
                                .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(53, 53, 53))))))
        );
        SettingLayout.setVerticalGroup(
            SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SettingLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel43)
                    .addComponent(jLabel65, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(94, 94, 94)
                .addGroup(SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminName, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(adminEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(76, 76, 76)
                .addGroup(SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminPass, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(adminPh, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(77, 77, 77)
                .addGroup(SettingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminAns, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(adminQue, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(76, 76, 76)
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(127, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Setting", Setting);

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel44.setText("Search Teacher");

        searchTeacher.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchTeacherKeyReleased(evt);
            }
        });

        teacherTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Email", "ph#", "Password", "Security Question", "Security Answer"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        teacherTable.setShowGrid(true);
        teacherTable.setSurrendersFocusOnKeystroke(true);
        jScrollPane6.setViewportView(teacherTable);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 736, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel44)
                        .addComponent(searchTeacher, javax.swing.GroupLayout.PREFERRED_SIZE, 718, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel44)
                .addGap(38, 38, 38)
                .addComponent(searchTeacher, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 440, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("List of Teacher", jPanel10);

        jLabel45.setText("jLabel31");

        jLabel50.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel50.setText("Teacher");

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel51.setText("Section");

        teacherCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                teacherCourseActionPerformed(evt);
            }
        });

        jPanel11.setBackground(new java.awt.Color(0, 153, 153));
        jPanel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel11MouseClicked(evt);
            }
        });

        jLabel52.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 255, 255));
        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/portal.png"))); // NOI18N
        jLabel52.setText("Assign");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel52, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel52, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
        );

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel53.setText("Course");

        workloadtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Teacher", "Course", "Section", "Class Days", "Class Time"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane10.setViewportView(workloadtable);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 745, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(teacherName, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(50, 50, 50)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(teacherCourse, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(55, 55, 55)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel51, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(teacherSection, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 27, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel50)
                    .addComponent(jLabel51)
                    .addComponent(jLabel53))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(teacherName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(teacherCourse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(teacherSection, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                .addComponent(jLabel45)
                .addContainerGap())
        );

        jTabbedPane3.addTab("WorkLoad Portal", jPanel9);

        jPanel13.setBackground(new java.awt.Color(0, 153, 153));

        jLabel55.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/upload.png"))); // NOI18N
        jLabel55.setText("Resolve");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel55)
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel55, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
        );

        status_combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "Approved", "Cancelled" }));

        jLabel67.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel67.setText("Teacher");

        advisorPortalSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                advisorPortalSearchActionPerformed(evt);
            }
        });

        studentStatusTable.setAutoCreateRowSorter(true);
        studentStatusTable.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        studentStatusTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        studentStatusTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null}
            },
            new String [] {
                "Student Name", "Course", "Section", "Day", "Time", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        studentStatusTable.setRowMargin(3);
        studentStatusTable.setShowGrid(true);
        jScrollPane7.setViewportView(studentStatusTable);
        if (studentStatusTable.getColumnModel().getColumnCount() > 0) {
            studentStatusTable.getColumnModel().getColumn(5).setCellEditor(new DefaultCellEditor(status_combo));
        }

        jPanel19.setBackground(new java.awt.Color(0, 153, 153));
        jPanel19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jPanel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel19MouseClicked(evt);
            }
        });

        jLabel68.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 255, 255));
        jLabel68.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel68.setText("Resolve");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addComponent(jLabel68, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel68, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel67)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(advisorPortalSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(96, 96, 96))))
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(439, 439, 439)
                        .addComponent(status_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 753, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(35, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel67)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(advisorPortalSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(status_combo, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Advisor Portal", jPanel8);

        javax.swing.GroupLayout TeacherLayout = new javax.swing.GroupLayout(Teacher);
        Teacher.setLayout(TeacherLayout);
        TeacherLayout.setHorizontalGroup(
            TeacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TeacherLayout.createSequentialGroup()
                .addComponent(jTabbedPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 794, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        TeacherLayout.setVerticalGroup(
            TeacherLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TeacherLayout.createSequentialGroup()
                .addComponent(jTabbedPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 617, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Teacher Portal", Teacher);

        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel56.setText("User Portal");

        jLabel57.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel57.setText("Name");

        jLabel58.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel58.setText("Phone Number");

        jLabel59.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel59.setText("Email");

        jLabel60.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel60.setText("Password");

        jLabel61.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel61.setText("Security Questions");

        jLabel62.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel62.setText("Role");

        jLabel63.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel63.setText(" Answers");

        userRole.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Student", "Teacher" }));

        userQue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "What is your pet name?", "What is your School name?", "What is your favourite teacher name?" }));

        jPanel12.setBackground(new java.awt.Color(0, 153, 153));
        jPanel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel12MouseClicked(evt);
            }
        });

        jLabel64.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(255, 255, 255));
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel64.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ams/icon/portal.png"))); // NOI18N
        jLabel64.setText("Register");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(jLabel64, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(67, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel64))
        );

        javax.swing.GroupLayout UserportalLayout = new javax.swing.GroupLayout(Userportal);
        Userportal.setLayout(UserportalLayout);
        UserportalLayout.setHorizontalGroup(
            UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UserportalLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(UserportalLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UserportalLayout.createSequentialGroup()
                                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(userQue, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(154, 154, 154)
                                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(userRole, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(UserportalLayout.createSequentialGroup()
                                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel63, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(userAns, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(UserportalLayout.createSequentialGroup()
                        .addComponent(userNum, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(UserportalLayout.createSequentialGroup()
                        .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(UserportalLayout.createSequentialGroup()
                                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(UserName, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel58))
                                .addGap(152, 152, 152)
                                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(userEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel60)
                                    .addComponent(userPass, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(UserportalLayout.createSequentialGroup()
                                .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(335, 335, 335)
                                .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );
        UserportalLayout.setVerticalGroup(
            UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UserportalLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel56)
                .addGap(18, 18, 18)
                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel59, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel57))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(userEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(UserName, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel58)
                    .addComponent(jLabel60))
                .addGap(28, 28, 28)
                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(userNum, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userPass, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel61)
                    .addComponent(jLabel62))
                .addGap(26, 26, 26)
                .addGroup(UserportalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(userQue, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userRole, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(jLabel63)
                .addGap(18, 18, 18)
                .addComponent(userAns, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(103, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("User Portal", Userportal);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 0, 770, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jLabel20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel20MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jLabel20MouseClicked

    private void jLabel21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel21MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_jLabel21MouseClicked

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_jLabel22MouseClicked

    private void jLabel23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel23MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_jLabel23MouseClicked

    private void jLabel24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel24MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(5);
    }//GEN-LAST:event_jLabel24MouseClicked

    private void jLabel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel25MouseClicked
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(6);
    }//GEN-LAST:event_jLabel25MouseClicked

    private void jLabel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseClicked
        int dis = JOptionPane.showConfirmDialog(null, "Do you want to loggged out");
        if (dis == 0) {
            this.setVisible(false);
            this.dispose();
            Login.obj = null;
            Signup.obj = null;
            new Login().setVisible(true);
        }
    }//GEN-LAST:event_jLabel26MouseClicked

    private void WelcomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_WelcomeMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_WelcomeMouseClicked

    private void AddSectionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddSectionMouseClicked
        // TODO add your handling code here:
        model = (DefaultTableModel) courseTable.getModel();
        model.addRow(new Object[1]);

    }//GEN-LAST:event_AddSectionMouseClicked

    private void AddSectionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddSectionMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_AddSectionMouseEntered

    private void deletesectionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deletesectionMouseClicked
        // TODO add your handling code here:
        model = (DefaultTableModel) courseTable.getModel();
        int index = model.getRowCount() - 1;
        if (index >= 0) {
            model.removeRow(index);
        } else {
            JOptionPane.showMessageDialog(null, "section table already empty");
        }

    }//GEN-LAST:event_deletesectionMouseClicked

    private void jPanel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel7MouseClicked
        // TODO add your handling code here:
        try {
            if (!courseName.getText().isEmpty() && !courseCode.getText().isEmpty()) {
                Course c = new Course();
                c.setName(courseName.getText());
                c.setC_code(courseCode.getText());

                model = (DefaultTableModel) courseTable.getModel();
                int rowCount = model.getRowCount();

                if (rowCount > 0) {
                    ArrayList<Section> sections = new ArrayList<>(rowCount); // Set initial capacity
                    for (int i = 0; i < rowCount; i++) {
                        Section section = new Section();
                        section.setName(model.getValueAt(i, 0).toString());
                        section.setClass_days(model.getValueAt(i, 1).toString());
                        section.setClass_time_slot(model.getValueAt(i, 2).toString().trim());
                        sections.add(section);
                    }
                    c.setSections(sections);

                    boolean isCreated = University.createCourse(c);
                    University.dialogeMsg(isCreated ? "Course created successfully" : "Course creation failed. Course might already exist.");
                    JOptionPane.showMessageDialog(null, courseName.getText());
                    addCourse();
                    courseCode.setText("");
                    courseName.setText("");
                    model.setRowCount(0);
                } else {
                    University.dialogeMsg("No sections created till now");
                }
            } else {
                University.dialogeMsg("Course name and code cannot be empty");
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }

    }//GEN-LAST:event_jPanel7MouseClicked

    private void A_PortalSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_PortalSectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_A_PortalSectionActionPerformed

    private void createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createActionPerformed
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) attendanceTable.getModel();
            model.setRowCount(0);
            String[] students = University.specifcEnrolledStudent(A_portalCourse.getSelectedItem().toString(), A_PortalSection.getSelectedItem().toString());
            if (students != null) {
                for (String student : students) {
                    model.addRow(new Object[]{student, false});
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_createActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) attendanceTable.getModel();
            if (model.getRowCount() > 0) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    Attendance e = new Attendance(model.getValueAt(i, 0).toString(), model.getValueAt(i, 1).toString(), A_portalCourse.getSelectedItem().toString());
                    University.markAttendance(e);
                }
                model.setRowCount(0);
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void A_report_sectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_report_sectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_A_report_sectionActionPerformed

    private void studentSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentSectionActionPerformed
        // TODO add your handling code here:
        if (course.getSelectedItem() != null && studentSection.getSelectedItem() != null) {
            teacher.setText(University.TeacherWorkLoad(course.getSelectedItem().toString(), studentSection.getSelectedItem().toString()));
        }
    }//GEN-LAST:event_studentSectionActionPerformed

    private void studentSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_studentSearchKeyReleased
        // TODO add your handling code here:
        ArrayList<User> obj = University.search(studentSearch.getText(), "Student");
        if (obj != null) {
            searchedStudents(obj, studentTable);
        } else {
            showStudentList("Sudent", studentTable);
        }
    }//GEN-LAST:event_studentSearchKeyReleased

    private void teacherCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_teacherCourseActionPerformed
        // TODO add your handling code here:
        try {
            if (teacherCourse.getSelectedItem() != null) {
                teacherSection.removeAllItems();
                String selectedCourse = teacherCourse.getSelectedItem().toString();
                String[] sections = University.SectionName(selectedCourse);
                if (sections.length > 0) {
                    for (String s : sections) {
                        teacherSection.addItem(s);
                    }
                }
            }
        } catch (Exception e) {

        }
    }//GEN-LAST:event_teacherCourseActionPerformed

    private void courseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_courseActionPerformed
        // TODO add your handling code here:
        try {
            if (course.getSelectedItem() != null) {
                studentSection.removeAllItems();
                String selectedCourse = course.getSelectedItem().toString();
                String[] sections = University.SectionName(selectedCourse);
                if (sections.length > 0) {
                    for (String s : sections) {
                        studentSection.addItem(s);
                    }
                }
            }
        } catch (Exception e) {

        }
    }//GEN-LAST:event_courseActionPerformed

    private void jPanel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel6MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) studentEnrollmentTable.getModel();
            User u = University.UserSearchByName(studentName.getSelectedItem().toString(), "Student");
            User u1 = University.UserSearchByName(teacher.getText(), "Teacher");
            Course c = University.getCourseWithSections(course.getSelectedItem().toString(), studentSection.getSelectedItem().toString());
            String day = "";
            String time = "";
            boolean flag = false;
            for (int i = 0; i < 1; i++) {
                day = c.getSections().get(i).getClass_days();
                time = c.getSections().get(i).getClass_time_slot();
            }
            if (studentEnrollmentTable.getRowCount() > 0) {
                for (int i = 0; i < studentEnrollmentTable.getRowCount(); i++) {
                    for (Section s : c.getSections()) {
                        if (model.getValueAt(i, 1).toString().equalsIgnoreCase(c.getName())
                                && model.getValueAt(i, 0).toString().equalsIgnoreCase(u.getName())) {
                            if (model.getValueAt(i, 3).toString().equalsIgnoreCase(s.getName())) {
                                University.dialogeMsg("Enrolled already");
                                flag = true;
                            } else {
                                University.dialogeMsg("Enrolled already");
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (u1 != null) {
                if (u != null && c != null && flag == false) {
                    Enrollment enroll = new Enrollment((Student) u, c, (Teacher) u1, "Pending");
                    model.addRow(new Object[]{
                        u.getName(),
                        c.getName(),
                        u1.getName(),
                        studentSection.getSelectedItem().toString(),
                        day,
                        time
                    });
                    if (University.Enrollment(enroll)) {
                        University.dialogeMsg("Enrolled Sussessfully");
                    }
                }
            } else {
                University.dialogeMsg("Cannot enroll into section as teacher is not assigned yet");
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel6MouseClicked

    private void searchTeacherKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchTeacherKeyReleased
        // TODO add your handling code here:
        ArrayList<User> obj = University.search(searchTeacher.getText(), "Teacher");
        if (obj != null) {
            searchedStudents(obj, teacherTable);
        } else {
            showStudentList("Teacher", teacherTable);
        }
    }//GEN-LAST:event_searchTeacherKeyReleased

    private void advisorPortalSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_advisorPortalSearchActionPerformed
        // TODO add your handling code here:
        try {
            if (advisorPortalSearch.getSelectedItem() != null) {
                model = (DefaultTableModel) studentStatusTable.getModel();
                model.setRowCount(0);
                ArrayList<Enrollment> enroll = University.advisorValues(advisorPortalSearch.getSelectedItem().toString());
                if (enroll != null) {
                    for (Enrollment e : enroll) {
                        ArrayList<Section> sections = e.getCourse().getSections();
                        for (Section section : sections) {
                            Object[] col = new Object[6];
                            col[0] = e.getStd().getName();
                            col[1] = e.getCourse().getName();
                            col[2] = section.getName();
                            col[3] = section.getClass_days();
                            col[4] = section.getClass_time_slot();
                            col[5] = e.getStatus();
                            model.addRow(col);
                        }
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }

    }//GEN-LAST:event_advisorPortalSearchActionPerformed

    private void jPanel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel11MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) workloadtable.getModel();
            User u = University.UserSearchByName(teacherName.getSelectedItem().toString(), "Teacher");
            Course c = University.getCourseWithSections(teacherCourse.getSelectedItem().toString(), teacherSection.getSelectedItem().toString());
            String day = "";
            String time = "";
            boolean flag = false;
            for (int i = 0; i < 1; i++) {
                day = c.getSections().get(i).getClass_days();
                time = c.getSections().get(i).getClass_time_slot();
            }
            if (workloadtable.getRowCount() > 0) {
                for (int i = 0; i < workloadtable.getRowCount(); i++) {
                    for (Section s : c.getSections()) {
                        if (model.getValueAt(i, 1).toString().equalsIgnoreCase(c.getName())
                                && model.getValueAt(i, 2).toString().equalsIgnoreCase(s.getName())) {
                            if (model.getValueAt(i, 0).toString().equalsIgnoreCase(u.getName())) {
                                University.dialogeMsg("Already assigned");
                                flag = true;
                            } else {
                                University.dialogeMsg("Already assigned");
                                flag = true;
                            }
                        }
                    }
                }
            }
            if (u != null && c != null && flag == false) {
                WorkLoad workLoad = new WorkLoad((Teacher) u, c);
                model.addRow(new Object[]{
                    u.getName(),
                    c.getName(),
                    teacherSection.getSelectedItem().toString(),
                    day,
                    time
                });
                if (University.WorkLoad(workLoad)) {
                    University.dialogeMsg("Assigned Sussessfully");
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }

    }//GEN-LAST:event_jPanel11MouseClicked

    private void status_combo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_status_combo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_status_combo1ActionPerformed

    private void jLabel65MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel65MouseClicked
        // TODO add your handling code here:
        adminAns.setEditable(true);
        adminPass.setEditable(true);
        adminPh.setEditable(true);
    }//GEN-LAST:event_jLabel65MouseClicked

    private void jPanel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel14MouseClicked
        // TODO add your handling code here:
        User obj = new User();
        obj.setPassword(adminPass.getText().trim());
        obj.setPh_no(adminPh.getText().trim());
        obj.setEmail(adminEmail.getText().trim());
        obj.setName(adminName.getText().trim());
        obj.setSecurity_a(adminAns.getText().trim());
        obj.setSecurity_q(adminQue.getSelectedItem().toString().trim());
        if (obj.isValid()) {
            University.UpdateUser(obj, adminEmail.getText());
        }
    }//GEN-LAST:event_jPanel14MouseClicked

    private void jPanel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel12MouseClicked
        // TODO add your handling code here:
        User u = new User();
        try {
            u.setName(UserName.getText().trim());
            u.setEmail(userEmail.getText().trim());
            u.setPassword(userPass.getText().trim());
            u.setSecurity_q(userQue.getSelectedItem().toString());
            u.setSecurity_a(userAns.getText().trim());
            u.setRole(userRole.getSelectedItem().toString());
            u.setPh_no(userNum.getText().trim());
            if (u.isValid()) {
                University.registerUser(u);
                if (u.getRole().equalsIgnoreCase("Student")) {
                    model = (DefaultTableModel) studentTable.getModel();
                    model.setRowCount(0);
                    showStudentList("Student", studentTable);
                    studentName.addItem(u.getName());
                } else {
                    model = (DefaultTableModel) teacherTable.getModel();
                    model.setRowCount(0);
                    showStudentList("Teacher", teacherTable);
                    teacherName.addItem(u.getName());
                    advisorPortalSearch.addItem(u.getName());
                }
                UserName.setText("");
                userEmail.setText("");
                userPass.setText("");
                userAns.setText("");
                userNum.setText("");
                userRole.setSelectedIndex(0);
                userQue.setSelectedIndex(0);
            }
        } catch (IllegalArgumentException e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel12MouseClicked

    private void jLabel47MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel47MouseClicked
        // TODO add your handling code here:
        A_PortalSection.setEnabled(true);
        A_portalCourse.setEnabled(true);
        create.setEnabled(true);
    }//GEN-LAST:event_jLabel47MouseClicked

    private void jPanel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel19MouseClicked
        // TODO add your handling code here:
        try {
            if (advisorPortalSearch.getSelectedItem() != null) {
                model = (DefaultTableModel) studentStatusTable.getModel();
                ArrayList<Enrollment> enroll = University.advisorValues(advisorPortalSearch.getSelectedItem().toString());
                int rowCount = model.getRowCount();
                int enrollCount = enroll.size();
                int minCount = Math.min(rowCount, enrollCount);
                for (int i = 0; i < minCount; i++) {
                    Enrollment e = enroll.get(i);
                    String status = model.getValueAt(i, 5).toString();
                    e.setStatus(status);
                }
                University.dialogeMsg("Resolved");
                for (int i = model.getRowCount() - 1; i >= 0; i--) {
                    if (model.getValueAt(i, 5).toString().equalsIgnoreCase("approved")) {
                        model.removeRow(i);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel19MouseClicked

    private void A_portalCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_portalCourseActionPerformed
        // TODO add your handling code here:
        try {
            if (A_portalCourse.getSelectedItem() != null) {
                A_PortalSection.removeAllItems();
                String selectedCourse = A_portalCourse.getSelectedItem().toString();
                String[] courses = University.SectionName(selectedCourse);
                if (courses.length > 0) {
                    for (String s : courses) {
                        A_PortalSection.addItem(s);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_A_portalCourseActionPerformed

    private void A_report_courseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_A_report_courseActionPerformed
        // TODO add your handling code here:
        try {
            if (A_report_course.getSelectedItem() != null) {
                A_report_section.removeAllItems();
                String selectedCourse = A_report_course.getSelectedItem().toString();
                String[] courses = University.SectionName(selectedCourse);
                if (courses.length > 0) {
                    for (String s : courses) {
                        A_report_section.addItem(s);
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_A_report_courseActionPerformed

    private void jPanel25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel25MouseClicked
        // TODO add your handling code here:
        try {
            model = (DefaultTableModel) allAttendanceTable.getModel();
            model.setRowCount(0);
            String[] students = University.specifcEnrolledStudent(A_report_course.getSelectedItem().toString(), A_report_section.getSelectedItem().toString());
            if (students != null) {
                for (String student : students) {
                    if (University.specificStudentAttendance(student) != null) {
                        model.addRow(new Object[]{student, University.specificStudentAttendance(student)});
                    }
                }
            }
        } catch (Exception e) {
            University.dialogeMsg(e.getMessage());
        }
    }//GEN-LAST:event_jPanel25MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin_portal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin_portal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin_portal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin_portal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin_portal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> A_PortalSection;
    private javax.swing.JComboBox<String> A_portalCourse;
    private javax.swing.JComboBox<String> A_report_course;
    private javax.swing.JComboBox<String> A_report_section;
    private javax.swing.JLabel AddSection;
    private javax.swing.JPanel Attendance;
    private javax.swing.JPanel Course;
    private javax.swing.JPanel Setting;
    private javax.swing.JPanel Student;
    private javax.swing.JPanel Teacher;
    private javax.swing.JTextField UserName;
    private javax.swing.JPanel Userportal;
    private javax.swing.JPanel Welcome;
    private javax.swing.JTextField adminAns;
    private javax.swing.JTextField adminEmail;
    private javax.swing.JTextField adminName;
    private javax.swing.JTextField adminPass;
    private javax.swing.JTextField adminPh;
    private javax.swing.JComboBox<String> adminQue;
    private javax.swing.JComboBox<String> advisorPortalSearch;
    private javax.swing.JTable allAttendanceTable;
    private javax.swing.JTable attendanceTable;
    private javax.swing.JComboBox<String> course;
    private javax.swing.JTextField courseCode;
    private javax.swing.JTextField courseName;
    private javax.swing.JTable courseTable;
    private javax.swing.JButton create;
    private javax.swing.JPanel dashboard2;
    private javax.swing.JLabel date;
    private javax.swing.JLabel deletesection;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JLabel pic_label;
    private javax.swing.JTextField searchTeacher;
    private javax.swing.JComboBox<String> status_combo;
    private javax.swing.JComboBox<String> status_combo1;
    private javax.swing.JTable studentEnrollmentTable;
    private javax.swing.JComboBox<String> studentName;
    private javax.swing.JTextField studentSearch;
    private javax.swing.JComboBox<String> studentSection;
    private javax.swing.JTable studentStatusTable;
    private javax.swing.JTable studentTable;
    private javax.swing.JLabel teacher;
    private javax.swing.JComboBox<String> teacherCourse;
    private javax.swing.JComboBox<String> teacherName;
    private javax.swing.JComboBox<String> teacherSection;
    private javax.swing.JTable teacherTable;
    private javax.swing.JLabel time;
    private javax.swing.JTextField userAns;
    private javax.swing.JTextField userEmail;
    private javax.swing.JTextField userNum;
    private javax.swing.JTextField userPass;
    private javax.swing.JComboBox<String> userQue;
    private javax.swing.JComboBox<String> userRole;
    private javax.swing.JTable workloadtable;
    // End of variables declaration//GEN-END:variables
}
